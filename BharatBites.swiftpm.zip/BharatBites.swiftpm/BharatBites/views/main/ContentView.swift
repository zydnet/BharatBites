//
//  ContentView.swift
//  BharatBites
//
//  Created by user on 22/02/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        HomeView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
